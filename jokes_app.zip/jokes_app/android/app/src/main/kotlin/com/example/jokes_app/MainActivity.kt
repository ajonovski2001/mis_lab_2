package com.example.jokes_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()

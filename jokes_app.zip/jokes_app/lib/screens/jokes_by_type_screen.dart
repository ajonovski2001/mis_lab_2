import 'package:flutter/material.dart';
import '../services/api_services.dart';

class JokesByTypeScreen extends StatefulWidget {
  final String jokeType;

  JokesByTypeScreen({required this.jokeType});

  @override
  _JokesByTypeScreenState createState() => _JokesByTypeScreenState();
}

class _JokesByTypeScreenState extends State<JokesByTypeScreen> {
  List<dynamic> jokes = [];

  @override
  void initState() {
    super.initState();
    fetchJokesByType();
  }

  Future<void> fetchJokesByType() async {
    jokes = await ApiService.fetchJokesByType(widget.jokeType);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('${widget.jokeType} Jokes'),
      ),
      body: jokes.isEmpty
          ? Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: jokes.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text(jokes[index]['setup']),
                  subtitle: Text(jokes[index]['punchline']),
                );
              },
            ),
    );
  }
}
